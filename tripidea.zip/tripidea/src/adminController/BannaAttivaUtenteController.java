package adminController;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.Facade;
import model.Amministratore;
import model.Utente;


@WebServlet("/bannaAttivaUtente")
public class BannaAttivaUtenteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String nextPage = null;
		
		long id = Long.parseLong(request.getParameter("idUtente"));
		
		Facade facade = new Facade();
		facade.bannaAttivaUtente(id);
		
		List <Utente> utenti = facade.getTuttiUtenti();
		List <Utente> utentiLinked = new LinkedList<Utente>();
		utentiLinked.addAll(utenti);
	    
		
		request.setAttribute("utenti", utentiLinked);
		nextPage = "/adminPage.jsp";
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
		
	}
		

}