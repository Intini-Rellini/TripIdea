package adminController;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.Facade;
import model.Commento;
import model.Viaggio;

@WebServlet("/mostraCommentiAdmin")
public class MostraCommentiAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nextPage = "";
		
		long id = Long.parseLong(request.getParameter("idUtente"));
		
		Facade facade = new Facade();
		
		List <Commento> commenti = facade.getTuttiCommenti();
		List <Commento> commentiLinked = new LinkedList<Commento>();
		
		for(Commento commento: commenti) {
			if (commento.getUtente().getId()==id) commentiLinked.add(commento);
		}
		
		
		request.setAttribute("commenti", commentiLinked);
		nextPage = "/adminCommenti.jsp";
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
	}

}
