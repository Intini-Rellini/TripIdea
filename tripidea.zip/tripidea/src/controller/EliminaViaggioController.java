package controller;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.Facade;
import model.*;

@WebServlet("/eliminaViaggio")
public class EliminaViaggioController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		boolean errorExists;
		String nextPage = "/personalPage.jsp";
		
		long idViaggio = Long.parseLong(request.getParameter("idViaggio"));
		
		Facade facade = new Facade();
		facade.eliminaViaggio(idViaggio);
		
		
		if((Utente)(request.getSession().getAttribute("autenticato"))!=null) {
			Utente utente =  (Utente)(request.getSession().getAttribute("autenticato"));
	        request.getSession().setAttribute("autenticato", facade.getUtenteByID(utente.getId()));
	        request.setAttribute("messaggioDiAggiornamento", "Hai eliminato una tua scheda di viaggio!!!");
	        nextPage = "/personalPage.jsp";
		}
		
		else if((Amministratore)(request.getSession().getAttribute("adminAutenticato"))!=null) {
	        List <Utente> utenti = facade.getTuttiUtenti();
			List <Utente> utentiLinked = new LinkedList<Utente>();
			utentiLinked.addAll(utenti);
		    
			request.setAttribute("messaggioDiAggiornamento", "viaggio eliminato");
			request.setAttribute("utenti", utentiLinked);
			nextPage = "/adminPage.jsp";
			}

		
		else {
			nextPage = "/home.jsp";
		}
        
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
	}

}
