package controller;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Utente;
import model.Viaggio;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import service.Facade;

/**
 * Servlet to handle File upload request from Client
 * @author Javin Paul
 */
@WebServlet("/upload")
public class FileUploadHandlerTI extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String UPLOAD_DIRECTORY = "webapps/TripIdea/foto";
  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	boolean errorExists = false;
    	String nextPage = "";
    	String nomeFile="";
    	
 
      
        //process only if its multipart content
        if(ServletFileUpload.isMultipartContent(request)){
            try {
                List<FileItem> multiparts = new ServletFileUpload(
                                         new DiskFileItemFactory()).parseRequest(request);
              
                for(FileItem item : multiparts){
                    if(!item.isFormField() && item.getContentType().substring(0, 6).equals("image/")){
                        String name = new File(item.getName()).getName();
                        
                        FileReader fr = new FileReader("webapps/TripIdea/foto/idFoto.txt");
                        BufferedReader b;
                	    b=new BufferedReader(fr);
                	    int id = Integer.parseInt(b.readLine());
                	    fr.close();
                	    PrintWriter writer = new PrintWriter("webapps/TripIdea/foto/idFoto.txt", "UTF-8");
                	    writer.println(id+1);
                	    writer.close();
                	    nomeFile="tripidea-"+id+"-"+name;
                	    
                	    if(item.getContentType().substring(0, 6).equals("image/")) item.write( new File(UPLOAD_DIRECTORY + File.separator + nomeFile));
                	    else {
                	    	errorExists = true;
                	    	request.setAttribute("formatError", "Sono consentite solo immagini");
                	    }
                       
                    }
                }
           
               //File uploaded successfully
               request.setAttribute("message", "File Uploaded Successfully");
               request.setAttribute("path", "foto/"+nomeFile);
            } catch (Exception ex) {
               request.setAttribute("message", "File Upload Failed due to " + ex);
               errorExists = true;
            }          
         
        }else{
            request.setAttribute("message",
                                 "Sorry this Servlet only handles file upload request");
            errorExists = true;
        }
        
        if (errorExists) {
			nextPage = "/aggiungiFoto.jsp";
			request.getRequestDispatcher(nextPage).forward(request, response);
			
		}
		else {
			
				long idViaggio = (Long)(request.getSession().getAttribute("idViaggio"));
				request.getSession().removeAttribute("idViaggio");
				Facade facade = new Facade();
				Viaggio viaggio = facade.getViaggioByID(idViaggio);
				viaggio.setPathFoto("foto/"+nomeFile);
				facade.aggiornaViaggio(viaggio);
				Utente utente =  (Utente)(request.getSession().getAttribute("autenticato"));
		        request.getSession().setAttribute("autenticato", facade.getUtenteByID(utente.getId()));
		        response.sendRedirect("redirectUpload");
			
			
		}	

    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	boolean errorExists = false;
    	String nextPage = "/personalPage.jsp";
    	
    	request.getSession().removeAttribute("viaggio");
    	
    	request.getRequestDispatcher(nextPage).forward(request, response);
    	
    }
  
}


