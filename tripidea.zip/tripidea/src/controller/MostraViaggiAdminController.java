package controller;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.Facade;
import model.Viaggio;

@WebServlet("/mostraViaggiAdmin")
public class MostraViaggiAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nextPage = "";
		
		long id = Long.parseLong(request.getParameter("idUtente"));
		
		Facade facade = new Facade();
		
		List <Viaggio> viaggi = facade.getTuttiViaggi();
		List <Viaggio> viaggiLinked = new LinkedList<Viaggio>();
		
		for(Viaggio viaggio : viaggi) {
			if (viaggio.getUtente().getId()==id) viaggiLinked.add(viaggio);
		}
		
		
		request.setAttribute("viaggi", viaggiLinked);
		nextPage = "/adminViaggi.jsp";
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
	}

}
