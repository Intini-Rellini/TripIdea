package controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.Facade;
import model.MyDate;
import model.Regione;
import model.Utente;
import model.Viaggio;

@WebServlet("/nuovaScheda")
public class NuovoViaggioController extends HttpServlet{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		boolean errorExists = false;
		String nextPage = null;
		String titolo = request.getParameter("titolo");
		String descrizione = request.getParameter("descrizione");
		int c = 0;
		List<String> nomiRegioni = new ArrayList<String> ();
		while(request.getParameter("regione"+c) != null){ 
			nomiRegioni.add(request.getParameter("regione"+c));
			c++;
		}
		Set<String> hs = new HashSet<String>();
		hs.addAll(nomiRegioni);
		nomiRegioni.clear();
		nomiRegioni.addAll(hs);
		Collections.sort(nomiRegioni, String.CASE_INSENSITIVE_ORDER);
		
		Utente utente = (Utente)request.getSession().getAttribute("autenticato");
		String dataInizio = dataValida(request.getParameter("data inizio"));
		String dataFine = dataValida(request.getParameter("data fine"));
		Date dataI = null;
		Date dataF = null;
		Facade facade = new Facade();
		
		try {
			dataI = new SimpleDateFormat("yyyy-MM-dd").parse(dataInizio);
			dataF = new SimpleDateFormat("yyyy-MM-dd").parse(dataFine);
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		
		if (titolo.equals("")) {
			errorExists = true;
			request.setAttribute("titoloError", "Titolo Obbligatorio!");
		}
		if (descrizione.equals("")) {
			errorExists = true;
			request.setAttribute("descrizioneError", "Descrizione Obbligatoria!");
		}
		if (dataI == null) {
			errorExists = true;
			request.setAttribute("dateIError", "Data Non Valida!");
		}
		if (dataF == null) {
			errorExists = true;
			request.setAttribute("dateFError", "Data Non Valida!");
		}
		if (dataF != null && dataI != null && dataF.compareTo(dataI)<0) {
			errorExists = true;
			request.setAttribute("dateTempoError", "Sicuro di essere tornato prima di partire?");
		}
		
		if (dataF != null && dataI != null && (dataF.compareTo(new Date())>0 || dataI.compareTo(new Date())>0)) {
			errorExists = true;
			request.setAttribute("dateFuturoError", "WOW un viaggio nel futuro! Fai il serio...");
		}
		
		if(!errorExists && !facade.verificaDisponibilit�Scheda(titolo, utente)){
			errorExists = true;
			request.setAttribute("titoloError", "Hai gi� utilizzato questo titolo!");
		}
		
		if (errorExists) {
			nextPage = "/nuovoViaggio.jsp";
			request.setAttribute("titoloInserito", titolo);
			request.setAttribute("descrizioneInserita", descrizione);
			request.setAttribute("dataIInserita", dataI);
			request.setAttribute("dataFInserita", dataF);
		}
		else {
		Viaggio v = new Viaggio(titolo,"foto/default.png", descrizione, utente, dataI, dataF);
		
		
		facade.inserisciViaggio(v, nomiRegioni);
		Viaggio viaggio = facade.getViaggioByID(v.getId());
	    request.getSession().setAttribute("idViaggio",viaggio.getId());
		nextPage = "/aggiungiFoto.jsp";
		}
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
	}
	
	private String dataValida(String s){
		int anno,mese,giorno;
		try{
			anno = Integer.parseInt(s.substring(0, 4));
			mese = Integer.parseInt(s.substring(5, 7));
			giorno = Integer.parseInt(s.substring(8,10));
		} catch (NumberFormatException e){
			return null;
		} catch (StringIndexOutOfBoundsException e){
			return null;
		}
		if (anno < 1901 || anno > 2016) return null;
		if (mese < 1 || mese > 12) return null;
		
		int [] giorni = {31,29,31,30,31,30,31,31,30,31,30,31};
		
		
		if(giorno < 1 || giorno > giorni[mese - 1]) return null;
	
		if (giorno == 29 && mese == 2 && anno%4 != 0) return null;
		
		return s.substring(0, 4) + "-" + s.substring(5, 7) + "-" + s.substring(8,10);
	}

}