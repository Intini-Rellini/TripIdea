package controller;
import model.*;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import persistence.UtenteDaoJPA;
import service.Facade;
import model.Utente;


@WebServlet("/nuoviDati")
public class UtenteController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	private static final long maggiorenne = 568036800000L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		boolean errorExists = false;
		String nextPage = null;
		String user = request.getParameter("username");
		String password = request.getParameter("password");
		String ripPassword = request.getParameter("ripetiPassword");
		String email = request.getParameter("email");
		String dataSt = dataValida(request.getParameter("data"));
		Date data = null;
		Facade facade = new Facade();
		
		try {
			data = new SimpleDateFormat("yyyy-MM-dd").parse(dataSt);
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		
		
		if (user.equals("")) {
			errorExists = true;
			request.setAttribute("userError", "Utente Obbligatorio!");
		}
		if (password.equals("")) {
			errorExists = true;
			request.setAttribute("passwordError", "Password Obbligatoria!");
		}
		if (!ripPassword.equals(password)) {
			errorExists = true;
			request.setAttribute("ripetiPasswordError", "Password non ripetuta correttamente!");
		}
		if (email.equals("")) {
			errorExists = true;
			request.setAttribute("emailError", "indirizzo email Obbligatorio!");
		}
		if (data == null) {
			errorExists = true;
			request.setAttribute("dateError", "Data Non Valida!");
		}
		
		if (data != null && data.getTime() > ((new Date().getTime())-maggiorenne)){
			errorExists = true;
			request.setAttribute("maggiorenneError", "Devi Essere Maggiorenne!");
		}
		
		// Verifico che il nome dell'utente non sia gi� utilizzato
		if(!facade.verificaDisponibilit�Username(user)  && !errorExists){
			errorExists = true;
			request.setAttribute("userError", "username gi� utilizzato!");
		}
		
		if (errorExists) {
			nextPage = "/registrazione.jsp";
			request.setAttribute("userInserito", user);
			if (ripPassword.equals(password)){
				request.setAttribute("passwordInserita", password);
				request.setAttribute("passwordRipetuta", ripPassword);
			}
			request.setAttribute("emailInserita", email);
		}
		else {
		Utente u = new Utente(user, password, email, data, new MyDate());
		request.setAttribute("utente", u);
		request.setAttribute("passwordNonCriptata", password);
		
		facade.inserisciUtente(u);
		
		nextPage = "/riepilogo.jsp";
		}
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
	}
	
	private String dataValida(String s){
		int anno,mese,giorno;
		try{
			anno = Integer.parseInt(s.substring(0, 4));
			mese = Integer.parseInt(s.substring(5, 7));
			giorno = Integer.parseInt(s.substring(8,10));
		} catch (NumberFormatException e){
			return null;
		} catch (StringIndexOutOfBoundsException e){
			return null;
		}
		if (anno < 1901 || anno > 2016) return null;
		if (mese < 1 || mese > 12) return null;
		
		int [] giorni = {31,29,31,30,31,30,31,31,30,31,30,31};
		
		
		if(giorno < 1 || giorno > giorni[mese - 1]) return null;
	
		if (giorno == 29 && mese == 2 && anno%4 != 0) return null;
		
		return s.substring(0, 4) + "-" + s.substring(5, 7) + "-" + s.substring(8,10);
	}

}