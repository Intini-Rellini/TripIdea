package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Viaggio implements Comparable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(nullable = false)
	private String nome;
	
	@Column(nullable = false)
	private String pathFoto;
	
	@Column(nullable = false, length=5000)
	private String descrizione;
	
	@ManyToOne
	private Utente utente;
	
	@ManyToMany (mappedBy = "viaggi" , fetch = FetchType.EAGER)
	private List<Regione> regioni;
	
	@OneToMany (mappedBy = "viaggio", fetch = FetchType.EAGER)
	private List<Commento> commenti;
	
	@Column(nullable = false)
	@Temporal(TemporalType.DATE)
	private Date inizio;
	
	@Column(nullable = false)
	@Temporal(TemporalType.DATE)
	private Date fine;
	
	@Column(nullable = false)
	@Temporal(TemporalType.DATE)
	private Date dataInserimento;
	
	public Viaggio () {}
	
	public Viaggio (String nome,String pathFoto, String descrizione, Utente utente, Date inizio, Date fine){
		this.nome = nome;
		this.pathFoto = pathFoto;
		this.descrizione=descrizione;
		this.utente = utente;
		this.regioni = new ArrayList<Regione>();
		this.commenti = new ArrayList<Commento>();
		this.inizio = inizio;
		this.fine = fine;
		this.dataInserimento = new Date();
		utente.addViaggio(this);
	}
	
	public void addRegione(Regione regione){
		this.regioni.add(regione);
	}
	
	public void addCommento(Commento commento){
		this.commenti.add(commento);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String d) {
		this.descrizione = d;
	}

	public Utente getUtente() {
		return utente;
	}

	public void setUtente(Utente utente) {
		this.utente = utente;
	}

	public List<Regione> getRegioni() {
		return regioni;
	}

	public void setRegioni(List<Regione> regioni) {
		this.regioni = regioni;
	}

	public List<Commento> getCommenti() {
		return commenti;
	}

	public void setCommenti(List<Commento> commenti) {
		this.commenti = commenti;
	}

	public Date getInizio() {
		return inizio;
	}

	public void setInizio(Date inizio) {
		this.inizio = inizio;
	}

	public Date getFine() {
		return fine;
	}

	public void setFine(Date fine) {
		this.fine = fine;
	}

	public String getPathFoto() {
		return pathFoto;
	}

	public void setPathFoto(String pathFoto) {
		this.pathFoto = pathFoto;
	}
	
	public Date getDataInserimento() {
		return dataInserimento;
	}

	public void setDataInserimento(Date dataInserimento) {
		this.dataInserimento = dataInserimento;
	}

	@Override
	public int compareTo(Object viaggio) {
		return this.dataInserimento.compareTo(((Viaggio)viaggio).getDataInserimento());
	}
	
	
	


}
