package persistence;

import java.util.List;

import javax.persistence.EntityManager;

import model.Amministratore;


public interface AmministratoreDao {
	
	public void save(Amministratore admin, EntityManager em);  // Create
	public Amministratore findByPrimaryKey(Long id, EntityManager em);     // Retrieve
	public Amministratore findByName (String adminUser, EntityManager em);
	public List<Amministratore> findAll(EntityManager em);       
	public void update(Amministratore admin, EntityManager em); //Update
	public void delete(Amministratore admin, EntityManager em); //Delete
	public void deleteAll(EntityManager em);

}
