package persistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import model.Amministratore;
import model.Utente;

public class AmministratoreDaoJPA implements AmministratoreDao {

	@Override
	public void save(Amministratore admin, EntityManager em) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(admin);
		tx.commit();
		
	}

	@Override
	public Amministratore findByPrimaryKey(Long id, EntityManager em) {
		return null;
	}

	@Override
	public Amministratore findByName(String adminUser, EntityManager em) {
		EntityTransaction tx = em.getTransaction();
        Query q = em.createQuery("SELECT id FROM Amministratore where username=(:p1)");
        q.setParameter("p1", adminUser);
		
		tx.begin();
		Amministratore admin = null;
        if (q.getResultList().size() != 0) admin = em.find(Amministratore.class,q.getResultList().get(0));
		tx.commit();
		return admin;
	}

	@Override
	public List<Amministratore> findAll(EntityManager em) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Amministratore admin, EntityManager em) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Amministratore admin, EntityManager em) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(EntityManager em) {
		// TODO Auto-generated method stub
		
	}

}
