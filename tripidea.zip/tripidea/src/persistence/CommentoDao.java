package persistence;

import java.util.List;

import javax.persistence.EntityManager;

import model.Commento;
import model.Regione;
import model.Utente;
import model.Viaggio;

public interface CommentoDao {
	
	public void save(Commento commento, EntityManager em);  // Create
	public Commento findByPrimaryKey(Long id, EntityManager em);     // Retrieve
	public List<Commento> findByUtente (Utente utente , EntityManager em);
	public List<Commento> findByViaggio (Viaggio viaggio, EntityManager em);
	public List<Commento> findAll(EntityManager em);       
	public void update(Commento commento, EntityManager em); //Update
	public void delete(Commento commento, EntityManager em); //Delete
	public void deleteAll(EntityManager em);
	

}
