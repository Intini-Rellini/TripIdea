package persistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.transaction.Transaction;

import model.Commento;
import model.Utente;
import model.Viaggio;

public class CommentoDaoJPA implements CommentoDao {

	@Override
	public void save(Commento commento, EntityManager em) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(commento);
		tx.commit();

	}

	@Override
	public Commento findByPrimaryKey(Long id, EntityManager em) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Commento commento = em.find(Commento.class,id);
		tx.commit();
		return commento;
	}

	@Override
	public List<Commento> findByUtente(Utente utente, EntityManager em) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Commento> findByViaggio(Viaggio viaggio, EntityManager em) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Commento> findAll(EntityManager em) {
EntityTransaction tx = em.getTransaction();
		
		Query q = em.createQuery("FROM Commento");
		
		
		tx.begin();
        @SuppressWarnings("unchecked")
		List<Commento> commenti = q.getResultList();
		tx.commit();

		return commenti;
	}

	@Override
	public void update(Commento commento, EntityManager em) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.merge(commento);
		tx.commit();

	}

	@Override
	public void delete(Commento commento, EntityManager em) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.remove(commento);
		tx.commit();

	}

	@Override
	public void deleteAll(EntityManager em) {
		// TODO Auto-generated method stub

	}

}
