package persistence;

import java.util.List;

import javax.persistence.EntityManager;

import model.Regione;
import model.Utente;
import model.Viaggio;

public interface ViaggioDao {
	
	public void save(Viaggio viaggio,List<Regione> regioni, EntityManager em);  // Create
	public void save(Viaggio viaggio, EntityManager em);
	public Viaggio findByPrimaryKey(Long id, EntityManager em);     // Retrieve
	public Viaggio findByName (String user, EntityManager em);
	public List<Viaggio> findAll(EntityManager em);       
	public void update(Viaggio viaggio, EntityManager em); //Update
	public void delete(Viaggio viaggio, EntityManager em); //Delete
	public void deleteAll(EntityManager em);
	public Viaggio findByNameAndUser (String nome, Utente u, EntityManager em);
	

}
