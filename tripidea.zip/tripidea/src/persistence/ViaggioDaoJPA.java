package persistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import model.Regione;
import model.Utente;
import model.Viaggio;

public class ViaggioDaoJPA implements ViaggioDao {

	@Override
	public void save(Viaggio viaggio,List<Regione> regioni, EntityManager em) {

        EntityTransaction tx = em.getTransaction();
		
		tx.begin();
		em.persist(viaggio);
		for(Regione r: regioni) em.merge(r);
		tx.commit();

	}
	//Aggiunto
	public void save(Viaggio viaggio, EntityManager em){
		EntityTransaction tx = em.getTransaction();
		
		tx.begin();
		em.persist(viaggio);
		//em.merge(regioni);
		tx.commit();
	}

	@Override
	public Viaggio findByPrimaryKey(Long id, EntityManager em) {
        EntityTransaction tx = em.getTransaction();
	    tx.begin();
		Viaggio v = em.find(Viaggio.class, id);
		tx.commit();
		return v;
	}

	@Override
	public Viaggio findByName(String titoloViaggio, EntityManager em) {
		EntityTransaction tx = em.getTransaction();
        Query q = em.createQuery("SELECT id FROM Viaggio where nome=(:p1)");
        q.setParameter("p1", titoloViaggio);
		tx.begin();
		Viaggio viaggio = null;
        if (q.getResultList().size() != 0) viaggio = em.find(Viaggio.class,q.getResultList().get(0));
		tx.commit();
		return viaggio;
	}

	@Override
	public List<Viaggio> findAll(EntityManager em) {
        EntityTransaction tx = em.getTransaction();
		
		Query q = em.createQuery("FROM Viaggio");
		
		
		tx.begin();
        @SuppressWarnings("unchecked")
		List<Viaggio> viaggi = q.getResultList();
		tx.commit();

		return viaggi;
	}

	@Override
	public void update(Viaggio viaggio, EntityManager em) {
        EntityTransaction tx = em.getTransaction();
		
		tx.begin();
		em.merge(viaggio);
		tx.commit();

	}

	@Override
	public void delete(Viaggio viaggio, EntityManager em) {
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.remove(viaggio);
		tx.commit();
	}

	@Override
	public void deleteAll(EntityManager em) {
		// TODO Auto-generated method stub

	}

	@Override
	public Viaggio findByNameAndUser(String nome, Utente u, EntityManager em) {
		EntityTransaction tx = em.getTransaction();
        Query q = em.createQuery("SELECT id FROM Viaggio where utente_id=(:p1) and nome=(:p2)");
        q.setParameter("p1", u.getId());
        q.setParameter("p2", nome);
		tx.begin();
		Viaggio v = null;
        if (q.getResultList().size() != 0) v = em.find(Viaggio.class,q.getResultList().get(0));
		tx.commit();
		return v;
	}
	

}