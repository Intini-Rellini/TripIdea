package service;

import java.io.IOException;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import model.*;
import persistence.*;

public class Simulatore {
	
	public static void caricaRegioni() throws IOException {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		RegioneDaoJPA regioneDao = new RegioneDaoJPA();
		CaricatoreRegioni.caricaRegioni(em, regioneDao);
		em.close();
		emf.close();
		
	}
	
	public static void simula() throws IOException {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		
		//carica le regioni
		RegioneDaoJPA regioneDao = new RegioneDaoJPA();
		CaricatoreRegioni.caricaRegioni(em, regioneDao);
		
		//carica amministratori
		AmministratoreDaoJPA adminDao = new AmministratoreDaoJPA();
		Amministratore admin1 = new Amministratore("emanuele","emanuele");
		Amministratore admin2 = new Amministratore("enrico","enrico");
		
		
		adminDao.save(admin1, em);
		adminDao.save(admin2, em);
		
		
		//carica utenti
		UtenteDaoJPA utenteDao = new UtenteDaoJPA();
		Utente utente1 = new Utente("pippo","pip","pippo@paperopoli.com",new Date (561074400000L),new Date(1449874800000L));
		Utente utente2 = new Utente("topolino","topo","topastro@paperopoli.com",new Date (561074400000L),new Date(1455922800000L));
		Utente utente3 = new Utente("paperino","pape","pk@paperopoli.com",new Date (714434400000L),new Date(1462831200000L));
		
		
		utenteDao.save(utente1, em);
		utenteDao.save(utente2, em);
		utenteDao.save(utente3, em);
		
		//prepara descrizioni fittizie per i viaggi
		String s1 = ""; for(int i=0;i<50;i++) s1+="Tutti sulla neve! ";
		String s2 = ""; for(int i=0;i<50;i++) s2+="Alla scoperta delle isole ";
		String s3 = ""; for(int i=0;i<50;i++) s3+="I voli pindarici ";
		String s4 = ""; for(int i=0;i<50;i++) s4+="Benvenuti al sud ";
		String s5 = ""; for(int i=0;i<50;i++) s5+="Benvenuti al nord ";
		String s6 = ""; for(int i=0;i<50;i++) s6+="Famo pure na capatina al centro va... ";
		
		//carica viaggi
		ViaggioDaoJPA viaggioDao = new ViaggioDaoJPA();
		Viaggio v1 = new Viaggio("Tutti sulla neve!","foto/default_v1.jpg",s1,utente1,new Date(1469674800000L),new Date(1469874800000L));
		Viaggio v2 = new Viaggio("Alla scoperta delle isole","foto/default_v2.png",s2,utente2,new Date(1460274800000L),new Date(1465274800000L));
		Viaggio v3 = new Viaggio("I voli pindarici","foto/default_v3.jpg",s3,utente2,new Date(1460274800000L),new Date(1461874800000L));
		Viaggio v4 = new Viaggio("Benvenuti al sud","foto/default_v4.png",s4,utente3,new Date(1460834800000L),new Date(1460874800000L));
		Viaggio v5 = new Viaggio("Benvenuti al nord","foto/default_v5.jpg",s5,utente3,new Date(1460874800000L),new Date(1467874800000L));
		Viaggio v6 = new Viaggio("Famo pure na capatina al centro va...","foto/default_v6.jpg",s6,utente3,new Date(1466054800000L),new Date(1466874800000L));
		
		
		viaggioDao.save(v1, em);
		viaggioDao.save(v2, em);
		viaggioDao.save(v3, em);
		viaggioDao.save(v4, em);
		viaggioDao.save(v5, em);
		viaggioDao.save(v6, em);
		
		
		//accoppia regioni e viaggi
		Regione abruzzo = regioneDao.findByName("Abruzzo", em);
		Regione basilicata = regioneDao.findByName("Basilicata", em);
		Regione calabria = regioneDao.findByName("Calabria", em);
		Regione campania = regioneDao.findByName("Campania", em);
		Regione emilia = regioneDao.findByName("Emilia-Romagna", em);
		Regione friuli = regioneDao.findByName("Friuli-Venezia Giulia", em);
		Regione lazio = regioneDao.findByName("Lazio", em);
		Regione liguria = regioneDao.findByName("Liguria", em);
		Regione lombardia = regioneDao.findByName("Lombardia", em);
		Regione marche = regioneDao.findByName("Marche", em);
		Regione molise = regioneDao.findByName("Molise", em);
		Regione piemonte = regioneDao.findByName("Piemonte", em);
		Regione puglia = regioneDao.findByName("Puglia", em);	
		Regione sardegna = regioneDao.findByName("Sardegna", em);
		Regione sicilia = regioneDao.findByName("Sicilia", em);
		Regione toscana = regioneDao.findByName("Toscana", em);
		Regione trentino = regioneDao.findByName("Trentino-Alto Adige", em);
		Regione umbria = regioneDao.findByName("Umbria", em);
		Regione aosta = regioneDao.findByName("Valle dAosta", em);
		Regione veneto = regioneDao.findByName("Veneto", em);
				
																
		v1.addRegione(trentino);
		trentino.addViaggio(v1);
		v1.addRegione(aosta);
		aosta.addViaggio(v1);
		v1.addRegione(piemonte);
		piemonte.addViaggio(v1);
		
		v2.addRegione(sicilia);
		sicilia.addViaggio(v2);
		v2.addRegione(sardegna);
		sardegna.addViaggio(v2);
		
		v3.addRegione(umbria);
		umbria.addViaggio(v3);
		v3.addRegione(puglia);
		puglia.addViaggio(v3);
		v3.addRegione(sardegna);
		sardegna.addViaggio(v3);
		v3.addRegione(trentino);
		trentino.addViaggio(v3);
		
		
		v4.addRegione(campania);
		campania.addViaggio(v4);
		v4.addRegione(basilicata);
		basilicata.addViaggio(v4);
		v4.addRegione(calabria);
		calabria.addViaggio(v4);
		v4.addRegione(sicilia);
		sicilia.addViaggio(v4);
		v4.addRegione(puglia);
		puglia.addViaggio(v4);
		
		v5.addRegione(piemonte);
		piemonte.addViaggio(v5);
		v5.addRegione(liguria);
		liguria.addViaggio(v5);
		v5.addRegione(lombardia);
		lombardia.addViaggio(v5);
		v5.addRegione(friuli);
		friuli.addViaggio(v5);
		v5.addRegione(veneto);
		veneto.addViaggio(v5);

		v6.addRegione(lazio);
		lazio.addViaggio(v6);
		v6.addRegione(marche);
		marche.addViaggio(v6);
		v6.addRegione(abruzzo);
		abruzzo.addViaggio(v6);
		v6.addRegione(toscana);
		toscana.addViaggio(v6);
		v6.addRegione(emilia);
		emilia.addViaggio(v6);
		v6.addRegione(molise);
		molise.addViaggio(v6);
		
	
		viaggioDao.update(v1, em);
		viaggioDao.update(v2, em);
		viaggioDao.update(v3, em);
		viaggioDao.update(v4, em);
		viaggioDao.update(v5, em);
		viaggioDao.update(v6, em);
		
		//carica commenti
		CommentoDao commentoDao = new CommentoDaoJPA();
		Commento c1 = new Commento (utente2, v1, "ehi pippo bel viaggio!", new Date());
		Commento c2 = new Commento (utente2, v4, "paperino non scottarti!", new Date());
		Commento c3 = new Commento (utente3, v1, "pippo attento alle valanghe", new Date());
		Commento c4 = new Commento (utente2, v5, "paperino! cartolina!", new Date());
		Commento c5 = new Commento (utente1, v2, "offioh topolino", new Date());
		Commento c6 = new Commento (utente1, v6, "offioh paperino", new Date());
		Commento c7 = new Commento (utente1, v5, "gulp gulp", new Date());
		Commento c8 = new Commento (utente1, v3, "... no comment", new Date());
		Commento c9 = new Commento (utente3, v2, "qua qua qua", new Date());
		commentoDao.save(c1, em);
		commentoDao.save(c2, em);
		commentoDao.save(c3, em);
		commentoDao.save(c4, em);
		commentoDao.save(c5, em);
		commentoDao.save(c6, em);
		commentoDao.save(c7, em);
		commentoDao.save(c8, em);
		commentoDao.save(c9, em);
		
		
		
		
		em.close();
		emf.close();
	}

}
