package adminController;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.Facade;
import service.PasswordCrypter;
import model.Amministratore;
import model.Utente;


@WebServlet("/adminLogin")
public class AdminAccessController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		boolean errorExists = false;
		String nextPage = null;
		
		String adminUser = request.getParameter("adminUsername");
		String adminPassword = PasswordCrypter.cripta(request.getParameter("adminPassword"));
		Facade facade = new Facade();
		Amministratore adminAutenticato = facade.autenticaAdmin(adminUser, adminPassword);
		
		if (adminAutenticato == null){
			nextPage = "/home.jsp";
			request.setAttribute("adminLoginError", "dati errati");
		}
		
		else {
			
			request.getSession().setAttribute("adminAutenticato",adminAutenticato);
			
			List <Utente> utenti = facade.getTuttiUtenti();
			List <Utente> utentiLinked = new LinkedList<Utente>();
			utentiLinked.addAll(utenti);
		    
			
			request.setAttribute("utenti", utentiLinked);
			nextPage = "/adminPage.jsp";
			
		}
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
		
		
	}
	
	public void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String nextPage = null;
		 Facade facade = new Facade() ;
			
		List <Utente> utenti = facade.getTuttiUtenti();
		List <Utente> utentiLinked = new LinkedList<Utente>();
		utentiLinked.addAll(utenti);
		    
			
		request.setAttribute("utenti", utentiLinked);
		nextPage = "/adminPage.jsp";
			
		
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
		
		
	}

}
