package controller;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.Facade;
import model.*;

@WebServlet("/eliminaCommento")
public class EliminaCommentoController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		boolean errorExists;
		String nextPage = "/personalPage.jsp";
		
		long idCommento = Long.parseLong(request.getParameter("idCommento"));
		
		Facade facade = new Facade();
		facade.eliminaCommento(idCommento);
		
		
		if((Utente)(request.getSession().getAttribute("autenticato"))!=null) {
			Utente utenteAutenticato =  (Utente)(request.getSession().getAttribute("autenticato"));
	        request.getSession().setAttribute("autenticato", facade.getUtenteByID(utenteAutenticato.getId()));
	        request.setAttribute("messaggioDiAggiornamento", "Hai eliminato un tuo commento!!!");
	        nextPage = "/personalPage.jsp";
		}
		
		else if((Amministratore)(request.getSession().getAttribute("adminAutenticato"))!=null) {
	        List <Utente> utenti = facade.getTuttiUtenti();
			List <Utente> utentiLinked = new LinkedList<Utente>();
			utentiLinked.addAll(utenti);
		    
			request.setAttribute("messaggioDiAggiornamento", "Commento eliminato");
			request.setAttribute("utenti", utentiLinked);
			nextPage = "/adminPage.jsp";
			}

		
		else {
			nextPage = "/home.jsp";
		}
        
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
	}

}
