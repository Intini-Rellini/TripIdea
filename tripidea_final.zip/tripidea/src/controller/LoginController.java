package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.Facade;
import service.PasswordCrypter;
import model.Utente;

@WebServlet("/login")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		boolean errorExists = false;
		String nextPage = null;
		
		String user = request.getParameter("username");
		String password = PasswordCrypter.cripta(request.getParameter("password"));
		Facade facade = new Facade();
		Utente autenticato = facade.autentica(user, password);
		
		if (autenticato == null) {
			request.setAttribute("loginError", "dati errati");
			errorExists = true;
			nextPage = "/home.jsp";
		}
		
		else if (autenticato.isBannato()){
			request.setAttribute("loginError", "utente bannato!");
			errorExists = true;
			nextPage = "/home.jsp";
		}
		
		else {
			HttpSession session = request.getSession();
			session.setAttribute("autenticato",autenticato);
			nextPage = "/personalPage.jsp";
			
		}
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
		
	}

}
