package controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.Facade;
import model.Commento;
import model.MyDate;
import model.Regione;
import model.Utente;
import model.Viaggio;

@WebServlet("/nuovoCommento")
public class NuovoCommentoController extends HttpServlet{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		boolean errorExists = false;
		String nextPage = "/schedaViaggio.jsp";
		String testo = request.getParameter("testo");
		Utente utenteAutenticato = (Utente)request.getSession().getAttribute("autenticato");
		long idViaggio = Long.parseLong(request.getParameter("idViaggio"));
		
		Facade facade = new Facade();
		Viaggio viaggio = facade.getViaggioByID(idViaggio);
		Collections.sort(viaggio.getCommenti());
		/*if (!viaggio.getCommenti().isEmpty()) {
			Commento ultimoCommento = viaggio.getCommenti().get(viaggio.getCommenti().size()-1);
			if (ultimoCommento.getUtente().getUserName().equals(utenteAutenticato.getUserName()) && ultimoCommento.getTesto().equals(testo)){
				errorExists = true;
				request.setAttribute("viaggio", viaggio);
				
			}
		}*/
		
		if (testo.equals("")) {
			errorExists = true;
			request.setAttribute("testoError", "Testo Obbligatorio!");
			request.setAttribute("viaggio", viaggio);
		}
		
		if (!errorExists){
			Commento commento = new Commento(utenteAutenticato, viaggio, testo, new Date());
			facade.inserisciCommento(commento);
			request.setAttribute("viaggio", viaggio);
			response.sendRedirect("redirectNuovoCommento");
			
		}
		
		else {
			
			ServletContext sc = getServletContext();
			RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
			rd.forward(request, response);
			
		}
		
		
	}
	
}