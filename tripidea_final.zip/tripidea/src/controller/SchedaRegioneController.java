package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.Facade;
import model.Regione;

@WebServlet("/visitaRegione")
public class SchedaRegioneController extends HttpServlet{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		boolean errorExists = false;
		String nextPage;
		String nomeRegione = request.getParameter("nomeRegione");
		if (nomeRegione == null) errorExists = true;
		Facade facade = new Facade();
		if (!errorExists){
			Regione regione = facade.getRegioneByName(nomeRegione);
			if(regione != null) request.setAttribute("regione", regione);
			else errorExists = true;
		}
		
		if (!errorExists) nextPage = "/viaggiRegione.jsp";
		else {
			request.setAttribute("regioneError", "regione non caricata correttamente");
			nextPage = "/italia.jsp";
		}
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
	}

}
