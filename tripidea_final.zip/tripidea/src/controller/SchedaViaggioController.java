package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.Facade;
import model.Viaggio;


@WebServlet("/schedaViaggio")
public class SchedaViaggioController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		boolean errorExists = false;
		String nextPage = null;
		String titoloViaggio = request.getParameter("titoloViaggio");
		
		Facade f = new Facade ();
		Viaggio viaggio = f.getViaggioByName(titoloViaggio);
		
		if (viaggio==null) errorExists = true;
		
		if(errorExists) {
			nextPage = "/personalPage.jsp";
		}
		
		else {
			request.setAttribute("viaggio", viaggio);
			nextPage = "/schedaViaggio.jsp";
			
		}
		
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(nextPage);
		rd.forward(request, response);
		
		
		
	}

}
