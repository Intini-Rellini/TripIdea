package main;

import java.io.IOException;

import service.Facade;
import service.Simulatore;

public class SitoMain {
	
	public static void main (String [] args) throws IOException{
		
		Simulatore.simula();

		
	}

}
