package model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Commento implements Comparable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@ManyToOne
	private Utente utente;
	
	@Column (nullable = false)
	private String testo;
	
	@ManyToOne
	private Viaggio viaggio;
	
	@Column (nullable = false)
	private Date data;
	
	public Commento () {}
	
	public Commento(Utente utente, Viaggio viaggio, String testo, Date data) {
		this.utente = utente;
		this.testo = testo;
		this.data = data;
		this.viaggio = viaggio;
		utente.addCommento(this);
		viaggio.addCommento(this);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Utente getUtente() {
		return utente;
	}

	public void setUtente(Utente utente) {
		this.utente = utente;
	}

	public String getTesto() {
		return testo;
	}

	public void setTesto(String testo) {
		this.testo = testo;
	}

	public Viaggio getViaggio() {
		return viaggio;
	}

	public void setViaggio(Viaggio viaggio) {
		this.viaggio = viaggio;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	@Override
	public int compareTo(Object commento) {
		return this.data.compareTo(((Commento)commento).getData());
	}
	
	
	

}
