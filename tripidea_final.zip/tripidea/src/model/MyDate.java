package model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MyDate extends Date {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public MyDate() {
		super();
	}
	
	public MyDate(int i) {
		super(i);
	}
	
	public MyDate(long i) {
		super(i);
	}

	public MyDate(int a, int m, int g) {
		super();
		
	}

	public String myToString () {
		 DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		 return df.format(this);
	}

	
}
