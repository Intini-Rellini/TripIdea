package model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import service.PasswordCrypter;

@Entity
public class Utente implements Comparable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(nullable = false)
	private String userName;
	
	@Column(nullable = false, length=1000)
	private String password;
	
	@Column(nullable = false)
	private String email;

	@Column(nullable = false)
	@Temporal(TemporalType.DATE)
	private Date dataNascita;
	
	@Column(nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataIscrizione;
	
	@Column(nullable = false)
	private boolean bannato;
	
	@OneToMany (mappedBy = "utente", fetch = FetchType.EAGER)
	private List<Viaggio> viaggi;
	
	@OneToMany (mappedBy = "utente", fetch = FetchType.EAGER)
	private List<Commento> commenti;
	
	public Utente (){}
	
	public Utente(String userName, String password, String email, Date dataNascita, Date dataIscrizione){
		this.userName = userName;
		this.password = PasswordCrypter.cripta(password);
		this.email = email;
		this.dataNascita = dataNascita;
		this.dataIscrizione = dataIscrizione;
		this.bannato = false;
		this.viaggi = new ArrayList<Viaggio>();
		this.commenti = new ArrayList<Commento>();
	}
	
	public void addViaggio(Viaggio viaggio){
		this.viaggi.add(viaggio);
	}
	
	public void addCommento(Commento commento){
		this.commenti.add(commento);
	}
	
	public Long getId() {return id;}

	public void setId(Long id) {this.id = id;}
	
	public String getUserName(){return this.userName;}
	
	public void setUserName(String userName) {this.userName = userName;}
	
	public String getPassword(){return this.password;}

	public void setPassword(String password) {this.password = password;}

	public String getEmail() {return email;}

	public void setEmail(String email) {this.email = email;}

	public Date getDataNascita() {return dataNascita;}

	public void setDataNascita(MyDate dataNascita) {this.dataNascita = dataNascita;}

	public Date getDataIscrizione() {return dataIscrizione;}

	public void setDataIscrizione(MyDate dataIscrizione) {this.dataIscrizione = dataIscrizione;}

	public boolean isBannato() {return bannato;}

	public void setBannato(boolean bannato) {this.bannato = bannato;}

	public List<Viaggio> getViaggi() {return viaggi;}

	public void setViaggi(List<Viaggio> viaggi) {this.viaggi = viaggi;}

	public List<Commento> getCommenti() {return commenti;}

	public void setCommenti(List<Commento> commenti) {this.commenti = commenti;}
	
	public String dataToString () {
		 DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		 return df.format(this.dataNascita);
	}

	@Override
	public int compareTo(Object utente) {
		return this.getDataIscrizione().compareTo(((Utente)utente).getDataIscrizione());
	}


	@Override
	public boolean equals(Object utente) {
		return this.id==((Utente)utente).id;
	}
	
	

}
