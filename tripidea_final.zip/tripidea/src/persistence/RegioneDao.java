package persistence;

import javax.persistence.EntityManager;

import model.Regione;
import model.Utente;

public interface RegioneDao {
	
	public void save(Regione regione, EntityManager em);  // Create
	public Regione findByName (String nome, EntityManager em);

}
