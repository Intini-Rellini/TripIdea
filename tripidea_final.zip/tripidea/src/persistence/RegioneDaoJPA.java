package persistence;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import model.Regione;
import model.Utente;

public class RegioneDaoJPA implements RegioneDao {

	@Override
	public Regione findByName(String nome, EntityManager em) {
		EntityTransaction tx = em.getTransaction();
        Query q = em.createQuery("SELECT id FROM Regione where nome=(:p1)");
        q.setParameter("p1", nome);
		tx.begin();
		Regione r = null;
        if (q.getResultList().size() != 0) r = em.find(Regione.class,q.getResultList().get(0));
		tx.commit();
		return r;
	}

	@Override
	public void save(Regione regione, EntityManager em) {
        EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(regione);
		tx.commit();
		
	}

}
