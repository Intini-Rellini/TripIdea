package persistence;

import java.util.List;

import javax.persistence.EntityManager;

import model.Utente;



public interface UtenteDao {
	
	public void save(Utente utente, EntityManager em);  // Create
	public Utente findByPrimaryKey(Long id, EntityManager em);     // Retrieve
	public Utente findByName (String user, EntityManager em);
	public List<Utente> findAll(EntityManager em);       
	public void update(Utente studente, EntityManager em); //Update
	public void delete(Utente studente, EntityManager em); //Delete
	public void deleteAll(EntityManager em);
	
}


