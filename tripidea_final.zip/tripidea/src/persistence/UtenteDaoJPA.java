package persistence;

import java.util.List;

import javax.persistence.EntityManager;

import javax.persistence.EntityTransaction;

import javax.persistence.Query;


import model.Utente;

public class UtenteDaoJPA implements UtenteDao {

	@Override
	public void save(Utente utente, EntityManager em) {
		
        EntityTransaction tx = em.getTransaction();
		
		tx.begin();
		em.persist(utente);
		tx.commit();
		
	}

	@Override
	public Utente findByPrimaryKey(Long id, EntityManager em) {
        EntityTransaction tx = em.getTransaction();
		
		tx.begin();
		Utente u = em.find(Utente.class,id);
		tx.commit();
		
		return u;
	}

	@Override
	public List<Utente> findAll(EntityManager em) {
		EntityTransaction tx = em.getTransaction();
		
		Query q = em.createQuery("FROM Utente");
		
		
		tx.begin();
        @SuppressWarnings("unchecked")
		List<Utente> utenti = q.getResultList();
		tx.commit();

		return utenti;
	}

	@Override
	public void update(Utente utente, EntityManager em) {
		 EntityTransaction tx = em.getTransaction();
			
			tx.begin();
			em.merge(utente);
			tx.commit();

		
	}

	@Override
	public void delete(Utente studente,EntityManager em) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(EntityManager em) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Utente findByName(String user, EntityManager em) {
		EntityTransaction tx = em.getTransaction();
        Query q = em.createQuery("SELECT id FROM Utente where username=(:p1)");
        q.setParameter("p1", user);
		
		tx.begin();
		Utente u = null;
        if (q.getResultList().size() != 0) u = em.find(Utente.class,q.getResultList().get(0));
		tx.commit();
		return u;
	}

}
