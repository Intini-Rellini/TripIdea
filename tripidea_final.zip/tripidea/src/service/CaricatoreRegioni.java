package service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.persistence.EntityManager;

import model.Regione;
import persistence.RegioneDaoJPA;

public class CaricatoreRegioni {
	
	public static void caricaRegioni (EntityManager em, RegioneDaoJPA regioneDao) throws IOException{
		FileReader f;
	    f= new FileReader("regioni.txt");

	    BufferedReader b;
	    b=new BufferedReader(f);
	    
	    for(int i=0;i<20;i++) {
	    	String nome = b.readLine();
	    	nome= normalizza (nome);
	    	String descrizione = b.readLine();
	    	descrizione = normalizza (descrizione);
	    	String link = b.readLine();
	    	link = normalizza (link);
	    	
	    	regioneDao.save(new Regione(nome, descrizione, link),em);
	    	
	    	b.readLine();
	    	
	    }
	    f.close();
		
	}
	
	private static String normalizza(String s) {
		if(s.charAt(0) == '|') return "";
		else return s.charAt(0)+normalizza(s.substring(1));
		
	}

}
