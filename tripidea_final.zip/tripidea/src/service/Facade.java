package service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import model.Amministratore;
import model.Commento;
import model.Regione;
import model.Utente;
import model.Viaggio;
import persistence.AmministratoreDaoJPA;
import persistence.CommentoDaoJPA;
import persistence.RegioneDaoJPA;
import persistence.UtenteDao;
import persistence.UtenteDaoJPA;
import persistence.ViaggioDaoJPA;

public class Facade {
	
	public void inserisciUtente (Utente utente) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		UtenteDaoJPA utenteDao = new UtenteDaoJPA();
		utenteDao.save(utente,em);
		
		em.close();
		emf.close();
	}
	
	public void inserisciRegione (Regione regione) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		RegioneDaoJPA regioneDao = new RegioneDaoJPA();
		regioneDao.save(regione,em);
		
		em.close();
		emf.close();
	}

	public Utente autentica(String user, String password) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		UtenteDaoJPA utenteDao = new UtenteDaoJPA();
		Utente u = utenteDao.findByName(user, em);
		em.close();
		emf.close();
		if (u!=null && password.equals(u.getPassword())) return u;
		return null;
	}
	
	public Amministratore autenticaAdmin(String adminUser, String adminPassword) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		AmministratoreDaoJPA amministratoreDao = new AmministratoreDaoJPA();
		Amministratore amministratore = amministratoreDao.findByName(adminUser, em);
		em.close();
		emf.close();
		if (amministratore!=null && adminPassword.equals(amministratore.getPassword())) return amministratore;
		return null;
	}
	

	public void inserisciViaggio(Viaggio viaggio, List<String> nomiRegioni) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		ViaggioDaoJPA viaggioDao = new ViaggioDaoJPA();
		RegioneDaoJPA regioneDao = new RegioneDaoJPA();
		List<Regione> regioni = new ArrayList<Regione>();
		//medodo aggiunto
		viaggioDao.save(viaggio, em);
		
		for (String s : nomiRegioni) System.out.println(s);
		
		for (String s: nomiRegioni){
			Regione regione = regioneDao.findByName(s, em);
			viaggio.addRegione(regione);
			regione.addViaggio(viaggio);
			
			
		}
		
		viaggioDao.update(viaggio, em);
		
		//se lo tolgo non salva l'ultima regione
		//viaggioDao.save(viaggio,regioni, em);
		
		em.close();
		emf.close();
		
	}

	public Regione getRegioneByName(String nomeRegione) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		RegioneDaoJPA regioneDao = new RegioneDaoJPA();
		Regione r = regioneDao.findByName(nomeRegione, em);
		em.close();
		emf.close();
		return r;
	}

	
	
	//Per verificare prima della registrazione
	public Boolean verificaDisponibilit�Username (String nome){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		UtenteDaoJPA utenteDao = new UtenteDaoJPA();
		Utente u = null;
		u = utenteDao.findByName(nome, em);
		em.close();
		emf.close();
		if (u != null) return false;
		return true;
	}
	
	//Per verificare prima dell'inserimento di un viaggio
	public Boolean verificaDisponibilit�Scheda (String nome, Utente utente){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		ViaggioDaoJPA viaggioDao = new ViaggioDaoJPA();
		Viaggio v = null;
		v = viaggioDao.findByNameAndUser(nome, utente, em);
		em.close();
		emf.close();
		if (v != null) return false;
		return true;
	}

	public void aggiornaViaggio(Viaggio v) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		ViaggioDaoJPA viaggioDao = new ViaggioDaoJPA();
		viaggioDao.update(v, em);
		em.close();
		emf.close();
		
	}

	public Viaggio getViaggioByName(String titoloViaggio) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		ViaggioDaoJPA viaggioDao = new ViaggioDaoJPA();
		Viaggio viaggio = viaggioDao.findByName(titoloViaggio, em);
		em.close();
		emf.close();
		return viaggio;
	}

	public void eliminaViaggio(long id) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		ViaggioDaoJPA viaggioDao = new ViaggioDaoJPA();
		Viaggio v = viaggioDao.findByPrimaryKey(id, em);
        if (v != null) {
        	RegioneDaoJPA regioneDao = new RegioneDaoJPA();
        	CommentoDaoJPA commentoDao = new CommentoDaoJPA();
        
        	Set<Commento> commenti = new HashSet<Commento>();
        	commenti.addAll(v.getCommenti());
        
        	for (Commento c : commenti){
        		eliminaCommento(c.getId());
        	}

        	for(Regione r : v.getRegioni()) {
        		Regione regione = regioneDao.findByName(r.getNome(), em);
        		regione.getViaggi().remove(v);		
        	}
        	
        	viaggioDao.delete(v, em);
        }
        	em.close();
        	emf.close();
	}
	

	public void eliminaCommento(long idCommento) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		CommentoDaoJPA commentoDao = new CommentoDaoJPA();
		Commento c = commentoDao.findByPrimaryKey(idCommento, em);
		if (c != null) commentoDao.delete(c, em);
		em.close();
		emf.close();
		
	}


	public Viaggio getViaggioByID(long id) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		ViaggioDaoJPA viaggioDao = new ViaggioDaoJPA();
		Viaggio v = viaggioDao.findByPrimaryKey(id, em);
		em.close();
		emf.close();
		return v;
	}
	
	public Commento getCommentoByID(long id) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		CommentoDaoJPA commentoDao = new CommentoDaoJPA();
		Commento commento = commentoDao.findByPrimaryKey(id, em);
		em.close();
		emf.close();
		return commento;
	}

	public Utente getUtenteByID(Long id) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		UtenteDao utenteDao = new UtenteDaoJPA();
		Utente utente = utenteDao.findByPrimaryKey(id, em);
		em.close();
		emf.close();
		return utente;
	}



	public void bannaAttivaUtente(long id) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		UtenteDao utenteDao = new UtenteDaoJPA();
		Utente utente = utenteDao.findByPrimaryKey(id, em);
		if(utente.isBannato()) utente.setBannato(false);
		else utente.setBannato(true);
		utenteDao.update(utente, em);
		em.close();
		emf.close();
	}
	
	public List<Utente> getTuttiUtenti() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		UtenteDao utenteDao = new UtenteDaoJPA();
		List<Utente> utenti = utenteDao.findAll(em);
		em.close();
		emf.close();
		return utenti;
	}

	public List<Viaggio> getTuttiViaggi() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		ViaggioDaoJPA viaggioDao = new ViaggioDaoJPA();
		List<Viaggio> viaggi = viaggioDao.findAll(em);
		em.close();
		emf.close();
		return viaggi;
	}
	
	public List<Commento> getTuttiCommenti() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		CommentoDaoJPA commentoDao = new CommentoDaoJPA();
		List<Commento> commenti = commentoDao.findAll(em);
		em.close();
		emf.close();
		return commenti;
	}

	public void inserisciCommento(Commento commento) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("tripidea-unit");
		EntityManager em = emf.createEntityManager();
		CommentoDaoJPA commentoDao = new CommentoDaoJPA();
		commentoDao.save(commento, em);
		em.close();
		emf.close();
	}




	

	
}
